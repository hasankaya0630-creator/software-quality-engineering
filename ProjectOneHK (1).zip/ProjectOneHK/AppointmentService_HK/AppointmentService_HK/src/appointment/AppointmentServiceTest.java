package appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

class AppointmentServiceTest {

    @Test
    void testAddAppointment() {

        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment(
                "12345",
                futureDate,
                "Doctor appointment"
        );

        assertDoesNotThrow(() -> {

            service.addAppointment(appointment);

        });

    }

    @Test
    void testAddDuplicateAppointment() {

        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointmentOne = new Appointment(
                "12345",
                futureDate,
                "Doctor appointment"
        );

        Appointment appointmentTwo = new Appointment(
                "12345",
                futureDate,
                "Dentist appointment"
        );

        service.addAppointment(appointmentOne);

        assertThrows(IllegalArgumentException.class, () -> {

            service.addAppointment(appointmentTwo);

        });

    }

    @Test
    void testDeleteAppointment() {

        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment(
                "12345",
                futureDate,
                "Doctor appointment"
        );

        service.addAppointment(appointment);

        assertDoesNotThrow(() -> {

            service.deleteAppointment("12345");

        });

    }

    @Test
    void testDeleteAppointmentNotFound() {

        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {

            service.deleteAppointment("12345");

        });

    }

}
