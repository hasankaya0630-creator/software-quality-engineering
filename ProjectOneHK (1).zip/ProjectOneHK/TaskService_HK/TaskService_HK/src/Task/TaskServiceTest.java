package Task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TaskServiceTest {

    private TaskService service;
    private Task task;

    @BeforeEach
    void setUp() {
        service = new TaskService();

        task = new Task(
                "12345",
                "Homework",
                "Complete Java assignment");
    }

    @Test
    void testAddTask() {
        service.addTask(task);

        assertEquals(task, service.getTask("12345"));
    }

    @Test
    void testAddDuplicateTaskId() {
        service.addTask(task);

        Task duplicateTask = new Task(
                "12345",
                "Another Task",
                "Another description");

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(duplicateTask);
        });
    }

    @Test
    void testDeleteTask() {
        service.addTask(task);

        service.deleteTask("12345");

        assertNull(service.getTask("12345"));
    }

    @Test
    void testDeleteTaskNotFound() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("99999");
        });
    }

    @Test
    void testUpdateTaskName() {
        service.addTask(task);

        service.updateTask(
                "12345",
                "Updated Task",
                "Complete Java assignment");

        assertEquals(
                "Updated Task",
                service.getTask("12345").getName());
    }

    @Test
    void testUpdateTaskDescription() {
        service.addTask(task);

        service.updateTask(
                "12345",
                "Homework",
                "Updated description");

        assertEquals(
                "Updated description",
                service.getTask("12345").getDescription());
    }

    @Test
    void testUpdateTaskNotFound() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTask(
                    "99999",
                    "Updated Task",
                    "Updated description");
        });
    }
}