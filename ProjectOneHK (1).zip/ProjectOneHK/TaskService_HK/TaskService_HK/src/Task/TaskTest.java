package Task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TaskTest {

    @Test
    void testTaskCreation() {
        Task task = new Task(
                "12345",
                "Homework",
                "Complete Java assignment");

        assertEquals("12345", task.getTaskId());
        assertEquals("Homework", task.getName());
        assertEquals("Complete Java assignment", task.getDescription());
    }

    @Test
    void testTaskIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "12345678901",
                    "Homework",
                    "Complete Java assignment");
        });
    }

    @Test
    void testTaskIdNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    null,
                    "Homework",
                    "Complete Java assignment");
        });
    }

    @Test
    void testNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "12345",
                    "This task name is too long",
                    "Complete Java assignment");
        });
    }

    @Test
    void testNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "12345",
                    null,
                    "Complete Java assignment");
        });
    }

    @Test
    void testDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "12345",
                    "Homework",
                    "This description is intentionally longer than fifty characters total.");
        });
    }

    @Test
    void testDescriptionNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "12345",
                    "Homework",
                    null);
        });
    }

    @Test
    void testUpdateName() {
        Task task = new Task(
                "12345",
                "Homework",
                "Complete Java assignment");

        task.setName("New Homework");

        assertEquals("New Homework", task.getName());
    }

    @Test
    void testUpdateDescription() {
        Task task = new Task(
                "12345",
                "Homework",
                "Complete Java assignment");

        task.setDescription("Updated description");

        assertEquals("Updated description", task.getDescription());
    }
}